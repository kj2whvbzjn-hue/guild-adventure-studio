# Build 347 — Studio Entry Routing

## Purpose
開発期間中の起動先をGK Studioへ固定し、Studioを開発ハブとして維持する。

## Changes
- リポジトリ直下の `index.html` の遷移先を `formal-v03/` から `studio/` へ変更。
- JavaScriptが無効な環境向けの自動遷移と手動リンクも `studio/` に統一。
- Studio内の既存「正式版を起動」導線は維持。
- ゲーム本編、固定キャンバス、Phase Controller、Battle Coreには変更なし。

## Temporary policy
正式リリース前までは Studio を既定の起動先とする。公開版への既定遷移は、正式リリース工程で別途切り替える。
