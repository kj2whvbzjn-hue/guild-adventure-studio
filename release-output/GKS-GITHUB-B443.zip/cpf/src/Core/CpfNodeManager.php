<?php
declare(strict_types=1);
namespace GK\CPF\Core;

use GK\CPF\History\CpfHistoryRepository;

final class CpfNodeManager
{
    private const TYPES = ['story','plot','chapter','map','boss','character','section','scene','event','milestone'];
    private const STATUSES = ['DRAFT','REVIEW','APPROVED','LOCKED','REJECTED','SUPERSEDED','ARCHIVED'];

    public function __construct(
        private JsonStore $s = new JsonStore(),
        private CpfHistoryRepository $h = new CpfHistoryRepository(),
        private CpfProjectMutation $mutation = new CpfProjectMutation()
    ) {}

    private function path(string $d, string $id): string { return "$d/nodes/$id.json"; }

    public function get(string $d, string $id): array
    {
        $n = $this->s->read($this->path($d, $id), null);
        if (!is_array($n)) throw new CpfException('NODE_NOT_FOUND', "Node not found: $id");
        return $n;
    }

    public function create(string $d, string $id, string $type, array $payload = [], array $meta = []): array
    {
        return $this->mutation->execute($d, ['nodes', 'history'], function () use ($d, $id, $type, $payload, $meta): array {
            if (!in_array($type, self::TYPES, true)) throw new CpfException('NODE_TYPE_INVALID', 'Invalid node type');
            if (is_file($this->path($d, $id))) throw new CpfException('NODE_EXISTS', 'Node exists');
            $now = date(DATE_ATOM);
            $n = array_merge(['node_id'=>$id,'node_type'=>$type,'status'=>'DRAFT','version'=>1,'locked'=>false,'manual_fields'=>[],'rule_version'=>'1.0.0','generator_id'=>null,'generator_version'=>null,'seed'=>null,'source_node_ids'=>[],'payload'=>$payload,'created_at'=>$now,'updated_at'=>$now], $meta);
            $this->validate($n);
            $this->s->write($this->path($d, $id), $n);
            $this->h->add($d, $id, 'CREATE', 0, 1, array_keys($payload), (string)($meta['change_reason'] ?? 'node created'));
            return $n;
        });
    }

    public function update(string $d, string $id, array $patch, string $reason = ''): array
    {
        return $this->mutation->execute($d, ['nodes', 'history'], function () use ($d, $id, $patch, $reason): array {
            $n = $this->get($d, $id);
            if ($n['locked']) throw new CpfException('NODE_LOCKED', 'Locked node', 3);
            $old = $n;
            foreach (($n['manual_fields'] ?? []) as $f) if (isset($patch['payload']) && array_key_exists($f, $n['payload'])) $patch['payload'][$f] = $n['payload'][$f];
            $n = array_replace_recursive($n, $patch);
            $n['version'] = $old['version'] + 1;
            $n['updated_at'] = date(DATE_ATOM);
            $n['change_reason'] = $reason;
            $this->validate($n);
            $this->s->write($this->path($d, $id), $n);
            $this->h->add($d, $id, 'UPDATE', $old['version'], $n['version'], $this->changed($old, $n), $reason);
            return $n;
        });
    }

    public function setStatus(string $d, string $id, string $status, array $extra = [], string $reason = ''): array
    {
        return $this->mutation->execute($d, ['nodes', 'history'], function () use ($d, $id, $status, $extra, $reason): array {
            if (!in_array($status, self::STATUSES, true)) throw new CpfException('STATUS_INVALID', 'Invalid status');
            $n = $this->get($d, $id); $from = $n['version'];
            if ($n['locked'] && $status !== 'LOCKED') throw new CpfException('NODE_LOCKED', 'Locked node', 3);
            $n['status'] = $status; $n['version']++; $n['updated_at'] = date(DATE_ATOM); $n = array_merge($n, $extra);
            $this->s->write($this->path($d, $id), $n);
            $this->h->add($d, $id, 'STATUS', $from, $n['version'], ['status'], $reason, ['status'=>$status]);
            return $n;
        });
    }

    public function lock(string $d, string $id, string $reason): array
    {
        return $this->mutation->execute($d, ['nodes', 'history'], function () use ($d, $id, $reason): array {
            $n = $this->get($d, $id);
            if (!in_array($n['status'], ['APPROVED','LOCKED'], true)) throw new CpfException('APPROVAL_REQUIRED', 'Approve before lock', 2);
            $n['locked']=true; $n['status']='LOCKED'; $n['lock_reason']=$reason; $n['version']++; $n['updated_at']=date(DATE_ATOM);
            $this->s->write($this->path($d,$id),$n);
            $this->h->add($d,$id,'LOCK',$n['version']-1,$n['version'],['locked','status'],$reason);
            return $n;
        });
    }

    public function unlock(string $d, string $id, string $reason): array
    {
        return $this->mutation->execute($d, ['nodes', 'history'], function () use ($d, $id, $reason): array {
            $n=$this->get($d,$id); $n['locked']=false; $n['status']='APPROVED'; $n['unlock_reason']=$reason; $n['version']++; $n['updated_at']=date(DATE_ATOM);
            $this->s->write($this->path($d,$id),$n);
            $this->h->add($d,$id,'UNLOCK',$n['version']-1,$n['version'],['locked','status'],$reason);
            return $n;
        });
    }

    public function all(string $d): array { $out=[]; foreach(glob("$d/nodes/*.json") ?: [] as $p) $out[]=$this->s->read($p); return $out; }
    private function validate(array $n): void { foreach(['node_id','node_type','status','version','locked','payload'] as $k) if(!array_key_exists($k,$n)) throw new CpfException('NODE_INVALID',"Missing $k"); if(!is_array($n['payload'])||$n['version']<1) throw new CpfException('NODE_INVALID','Invalid node'); }
    private function changed(array $a,array $b): array { $keys=[]; foreach(array_unique(array_merge(array_keys($a),array_keys($b))) as $k) if(($a[$k]??null)!==($b[$k]??null)&&!in_array($k,['version','updated_at'],true)) $keys[]=$k; return $keys; }
}
